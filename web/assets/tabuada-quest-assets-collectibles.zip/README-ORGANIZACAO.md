# Tabuada Quest — Assets organizados

Pacote processado automaticamente em 2026-09-25.

## Regras aplicadas

- Imagens PNG/JPG/BMP/TIFF convertidas para **WebP lossless** (`lossless=True`), sem redimensionamento.
- Arquivos que já eram WebP foram copiados sem re-encode, evitando qualquer perda adicional de qualidade.
- Nomes normalizados para `kebab-case`, minúsculos, sem espaços/acentos/underscores.
- Estrutura principal preservada em `assets/` conforme o projeto Tabuada Quest.
- Assets legados de UI foram encaminhados para diretórios canônicos.
- UUIDs visuais do fundo foram renomeados semanticamente (nuvens, céu, píer, lanterna).
- Duplicatas de nome/conteúdo são mapeadas; variantes não idênticas recebem sufixo `-variant-XX`.
- O ZIP de código encontrado dentro de `fundos/fundo01` foi preservado em `_archive/source-packages/`, sem ser misturado aos assets ativos.

## Mapeamento

Consulte:
- `_mapping/asset-name-map.json`
- `_mapping/asset-name-map.csv`

Total de entradas processadas: **285**.

Status: {"copied": 23, "copied-webp-no-reencode": 222, "converted-to-lossless-webp": 11, "duplicate-mapped": 28, "excluded-nested-source-zip": 1}
